
$(document).ready(function() {
  $('.questionTypes').append('<p class="test3Theme">theme javascsript</p>');
});